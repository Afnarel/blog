# -*- coding:utf-8 -*-
from GDB import GDB

if __name__ == '__main__':
  exe = 'crackme.exe'
  gdb = GDB('gdb.exe')
  
  # Ouverture du fichier a debugger
  gdb.send('file ' + exe)
  
  gdb.send('b strcmp')
  gdb.send('r toto')
  
  print gdb.send('info registers')
  print gdb.send('p/x $eax')
  
  out = gdb.send('x 0x28ff04')
  print out
  
  # On quitte GDB
  gdb.quit()
