# -*- coding: utf-8 -*-
from ircutils import bot
from datetime import datetime

class LogBot(bot.SimpleBot):
  def __init__(self, botname):
    bot.SimpleBot.__init__(self, botname)
    self.last_msg_time = None
    self.last_msg_date = None

  def on_channel_message(self, event):
    #self.send_message(event.target, event.message)
    if self.update_date(): # Day changed
      self.my_log(event.target, '==============================')
      self.my_log(event.target, '========== ' + self.last_msg_date + ' ==========')
      self.my_log(event.target, '==============================')
    self.my_log(event.target, self.last_msg_time + ': ' + event.user + '(' + event.source + '): ' + event.message)
    
  def my_log(self, channel, message):
    filename = self.filenameFromChannel(channel)
    f = open(filename, 'a')
    f.write(message + '\n')
    f.close()
  
  def filenameFromChannel(self, channel):
    return channel[1:] + '.log'
    
  def update_date(self):
    now = datetime.now()
    self.last_msg_time = now.strftime("%H:%M:%S")
    date_msg = now.strftime("%d/%m/%y")
    r = (self.last_msg_date != date_msg)
    self.last_msg_date = date_msg
    return r

if __name__ == "__main__":
  log = LogBot("Afnarel_bot")
  log.connect("irc.unice.fr", channel=["#polytech", "#songe", '#bdl', '#lesfruitsduchene'])
  log.start()
